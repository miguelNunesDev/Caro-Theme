<?php
var_dump($attributes)
?>

<section <?= get_block_wrapper_attributes() ?>>

    <h1 class="text-red-400">
        <span>
            <?php foreach ($attributes['rotators'] as $rotator) : ?>
                <b> <?= $rotator ?> </b>
            <?php endforeach; ?>
        </span>
        <?= $attributes['title'] ?>
    </h1>
    <p><?= $attributes['content'] ?></p>

</section>
import { __ } from '@wordpress/i18n';
import { SortableContainer, SortableElement } from 'react-sortable-hoc';
import { arrayMoveImmutable } from 'array-move';
import {
	useBlockProps,
	InspectorControls,
	RichText,
} from '@wordpress/block-editor';
import {
	TextControl,
	Panel,
	PanelBody,
	Button,
	Flex,
	FlexItem,
} from '@wordpress/components';
import ServerSideRender from '@wordpress/server-side-render';
import block from './block.json';
import './view.js';

export default function Edit({ attributes, setAttributes }) {
	const { rotators, title, content } = attributes;

	const removeRotator = (i) => {
		const newRotators = [...rotators];
		newRotators.splice(i, 1);
		setAttributes({
			rotators: newRotators,
		});
	};
	const addRotator = (val) => {
		const newRotators = [...rotators];
		newRotators.push(val);
		setAttributes({
			rotators: newRotators,
		});
	};
	const onRotatorChange = (val, i) => {
		const newRotators = [...rotators];
		newRotators[i] = val;
		console.log('on change');
		setAttributes({
			rotators: newRotators,
		});
	};

	const onSortEnd = ({ oldIndex, newIndex }) => {
		console.log('sort end');
		setAttributes({
			rotators: arrayMoveImmutable(rotators, oldIndex, newIndex),
		});
	};

	const SortableItem = SortableElement(({ sortIndex, value }) => (
		<Flex>
			<FlexItem>
				<TextControl
					label={`Rotator ${sortIndex}`}
					value={value}
					onChange={(val) => {
						console.log(this);
						const newRotators = [...rotators];
						newRotators[sortIndex] = val;
						console.log('on change');
						setAttributes({
							rotators: newRotators,
						});
						// onRotatorChange(val, sortIndex);
					}}
				/>
			</FlexItem>
			<FlexItem>
				<Button
					variant='secondary'
					onClick={(e) => {
						removeRotator(sortIndex);
					}}
				>
					-
				</Button>
			</FlexItem>
		</Flex>
	));

	const SortableList = SortableContainer(({ items }) => {
		return (
			<ul>
				{items.map((value, index) => (
					<SortableItem
						key={`item-${value}`}
						index={index}
						sortIndex={index}
						value={value}
						disabled
					/>
				))}
			</ul>
		);
	});

	const RotatorList = ({ items }) => {
		return (
			<ul>
				{items.map((value, i) => (
					<li>
						<Flex key={'item-' + i}>
							<FlexItem>
								<TextControl
									label={`Rotator ${i}`}
									value={value}
									onChange={(val) => onRotatorChange(val, i)}
								/>
							</FlexItem>
							<FlexItem>
								<Button
									variant='secondary'
									onClick={(e) => {
										removeRotator(i);
									}}
								>
									-
								</Button>
							</FlexItem>
						</Flex>
					</li>
				))}
			</ul>
		);
	};

	const MemoSortableList = React.memo(RotatorList);

	return (
		<>
			<InspectorControls key='setting'>
				<Panel>
					<PanelBody title='Contenido' initialOpen={true}>
						<ul>
							<li>
								<TextControl
									label='Title'
									value={title}
									onChange={(val) => setAttributes({ title })}
								/>
							</li>
							<li>
								<TextControl
									label='Content'
									value={content}
									onChange={(val) =>
										setAttributes({ content })
									}
								/>
							</li>
						</ul>
					</PanelBody>
					<PanelBody title='Text Rotator' initialOpen={true}>
						<ul>
							{rotators.map((value, i) => (
								<li>
									<Flex key={'item-' + i}>
										<FlexItem>
											<TextControl
												label={`Rotator ${i}`}
												value={value}
												onChange={(val) =>
													onRotatorChange(val, i)
												}
											/>
										</FlexItem>
										<FlexItem>
											<Button
												variant='secondary'
												onClick={(e) => {
													removeRotator(i);
												}}
											>
												-
											</Button>
										</FlexItem>
									</Flex>
								</li>
							))}
						</ul>
						<Button
							variant='primary'
							onClick={(e) => {
								addRotator('new text');
							}}
						>
							Add Rotator
						</Button>
					</PanelBody>
				</Panel>
			</InspectorControls>
			<div {...useBlockProps()} >
				<ServerSideRender block={block.name} attributes={attributes} />
			</div>
		</>
	);
}
